﻿using System;

namespace Amorph
{
    using UnityEngine;

    public class PlayerEffects : MonoBehaviour
    {
        #region Variables

        private const string Tag = nameof(PlayerEffects);

        private float speedMassLossEffect;

        private int aggressiveHandCount;
        private int immortalHandCount;

        #endregion


        #region Events

        public event Action OnAdditionalPassiveSlotsCountChanged;
        public event Action OnAdditionalInventorySlotsCountChanged;

        #endregion


        #region Properties

        public bool IsImmortal => immortalHandCount > 0;
        public bool IsAggressive => aggressiveHandCount > 0;
        public bool IsInvisible { get; private set; }

        public bool IsBushResist { get; private set; }

        public float SpeedEffect { get; private set; }
        public float FoodEatEffect { get; private set; }
        public float PlayerEatEffect { get; private set; }

        public float DropOpenTimeFactor { get; private set; } = 1f;
        public float PositiveEffectsTimeFactor { get; private set; } = 1f;
        public float NegativeEffectsTimeFactor { get; private set; } = 1f;
        public float LossMassFactor { get; private set; } = 1f;

        public int AdditionalInventorySlotsCount { get; private set; } = 0;
        public int AdditionalPassiveSlotsCount { get; private set; } = 0;

        public bool IsBleeding { get; private set; }
        
        public float IgnoreFreezeEffect { get; private set; }
        public float AdditionalMaxMass { get; private set; }
        public float BodyLifeTimeEffect { get; private set; } = 1;
        public float RespawnReductionEffect { get; private set; }
        public int DoubleDropChance { get; private set; } = -1;
        public bool NeedRespawnWithLastMass { get; set; }
        public float AdditionalRespawnMass { get; private set; }

        #endregion


        #region Public methods

        public void SetAggressiveWithHand(int handValue) =>
            aggressiveHandCount += handValue;

        public void SetImmortalWithHand(int handValue) =>
            immortalHandCount += handValue;

        public void SetInvisibility(bool isInvisibilityEnabled) =>
            IsInvisible = isInvisibilityEnabled;

        public void SetBushResist(bool isResist) =>
            IsBushResist = isResist;

        public void AddSpeedEffect(float deltaSpeed) =>
            SpeedEffect += deltaSpeed;

        public void AddFoodEatEffect(float deltaSize) =>
            FoodEatEffect += deltaSize;

        public void SetFoodEatEffect(float sizeEffect) =>
            FoodEatEffect = sizeEffect;

        public void AddPlayerEatEffectEffect(float deltaSize) =>
            PlayerEatEffect += deltaSize;

        public void AddDropOpenTimeFactor(float timeFactor) =>
            DropOpenTimeFactor += timeFactor;

        public void MultiplyDropOpenTimeFactor(float timeFactor) =>
            DropOpenTimeFactor *= timeFactor;

        public void AddPositiveEffectsTimeFactor(float timeFactor) =>
            PositiveEffectsTimeFactor += timeFactor;

        public void SetPositiveEffectsTimeFactor(float timeFactor) =>
            PositiveEffectsTimeFactor = timeFactor;

        public void AddNegativeEffectsTimeFactor(float timeFactor) =>
            NegativeEffectsTimeFactor += timeFactor;

        public void SetNegativeEffectsTimeFactor(float timeFactor) =>
            NegativeEffectsTimeFactor = timeFactor;

        public void SetLossMassFactor(float massFactor) =>
            LossMassFactor = massFactor;
        
        public void AddIgnoreFreezeEffect(float ignoreFreezeEffect) =>
            IgnoreFreezeEffect += ignoreFreezeEffect;
        
        public void AddAdditionalMaxMass(float additionalMaxMass) =>
            AdditionalMaxMass += additionalMaxMass;
        
        public void AddBodyLifeTimeEffect(float bodyLifeTimeEffect) =>
            BodyLifeTimeEffect += bodyLifeTimeEffect;
        
        public void AddRespawnReductionEffect(float respawnReductionEffect) =>
            RespawnReductionEffect += respawnReductionEffect;
        
        public void SetDoubleDropChance(int doubleDropChance) =>
            DoubleDropChance = doubleDropChance;
        
        public void AddAdditionalRespawnMass(float additionalRespawnMass) =>
            AdditionalRespawnMass += additionalRespawnMass;

        public void SetAdditionalInventorySlotsCount(int additionalInventorySlots)
        {
            AdditionalInventorySlotsCount = additionalInventorySlots;

            OnAdditionalInventorySlotsCountChanged?.Invoke();
        }

        public void SetAdditionalPassiveSlotsCount(int additionalPassiveSlots)
        {
            AdditionalPassiveSlotsCount = additionalPassiveSlots;

            OnAdditionalPassiveSlotsCountChanged?.Invoke();
        }

        public void SetIsBleeding(bool isBleeding) =>
            IsBleeding = isBleeding;

        #endregion
    }
}
