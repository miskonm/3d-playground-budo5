﻿namespace Amorph
{
    using System;
 
    public class InvisibleEffect<T> : Effect<T>, ICollidebleEffect
    {
        #region Constructor

        public InvisibleEffect(Action<T> setter, T startValue, T endValue, float duration, Type type, int level) : base(setter, startValue, endValue, duration, type, level)
        {
        }

        #endregion


        #region Public methods
        
        // public void InCollisionAction(AmorphPlayer owner, IPlayerBody eatablePlayerBody)
        // {
        //     if (!eatablePlayerBody.IsNull())
        //     {
        //         Complete();
        //     }
        // }
        //
        // public void OutCollisionAction(IPlayerBody body)
        // {
        // }

        #endregion
    }
}
