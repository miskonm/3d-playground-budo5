﻿namespace Amorph
{
    public class UsePassiveAbilityEventArgs : UseAbilityEventArgs
    {
        #region Poperties

        public float Duration { get; }
        public bool IsPassive { get; }

        #endregion


        #region Constructors

        public UsePassiveAbilityEventArgs(float duration, bool isPassive)
        {
            Duration = duration;
            IsPassive = isPassive;
        }

        #endregion
    }
}
