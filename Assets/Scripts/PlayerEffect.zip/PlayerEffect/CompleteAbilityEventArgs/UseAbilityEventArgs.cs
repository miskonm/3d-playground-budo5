﻿namespace Amorph
{
    public class UseAbilityEventArgs
    {
    }
}
