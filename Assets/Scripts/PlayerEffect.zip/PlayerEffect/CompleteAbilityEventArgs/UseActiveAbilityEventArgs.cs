﻿namespace Amorph
{
    public class UseActiveAbilityEventArgs : UseAbilityEventArgs
    {
    }
}
