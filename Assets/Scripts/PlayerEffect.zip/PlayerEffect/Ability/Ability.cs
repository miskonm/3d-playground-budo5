﻿using System;
using NaughtyAttributes;
using UnityEngine;

namespace Amorph
{

    public abstract class Ability : ScriptableObject
    {
        #region Variables

        [Header("Ability")]
        [ReadOnly]
        [SerializeField]
        protected int networkId;

        [SerializeField]
        private string abilityId;

        [SerializeField]
        private string nameKey;
        
        [SerializeField]
        private Sprite image;

        #endregion


        #region Properties

        [Obsolete]
        public static int Level => 1;
        public int NetworkId => networkId;

        public string AbilityId => abilityId;

        public string Name => null;//LocalizationDataBase.Instance.GetValueByKey(nameKey);
        public Sprite Image => image;

        #endregion


        #region Public methods

        public void SetNetworkId(int networkId)
        {
            this.networkId = networkId;
        }

        public abstract void Apply(GameObject sender, GameObject target, Action<UseAbilityEventArgs> successCallback = null, Action completeCallback = null);

        public abstract void Stop();

        #endregion
    }
}
