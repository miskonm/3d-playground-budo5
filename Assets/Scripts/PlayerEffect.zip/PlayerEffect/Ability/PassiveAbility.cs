﻿using UnityEngine;
using System;

namespace Amorph
{
    public abstract class PassiveAbility : Ability
    {
        #region Variables

        [Header("PassiveAbility")]
        [SerializeField]
        private string metaId;

        [SerializeField]
        private float duration;

        [SerializeField]
        protected bool isDebuff = false;

        [SerializeField]
        protected bool isPassive = true;

        [SerializeField]
        protected bool isSpecial;
        
        [SerializeField]
        protected bool needQueue = true;

        // [SerializeField]
        // private EffectPoolObject vfxPrefab;

        #endregion


        #region Properties

        public float Duration => duration;
        public bool IsPassive => isPassive;
        public bool IsDebuff => isDebuff;
        public bool IsSpecial => isSpecial;
        public bool NeedQueue => needQueue;

        // public EffectPoolObject VfxPrefab => vfxPrefab;

        public virtual Type Type => GetType();

        // This is nice solution.
        public int PickUpId => networkId;
        public string MetaId => metaId;

        #endregion


        #region Public methods

        public abstract BaseEffect GetEffect();

        public override void Apply(GameObject sender,
            GameObject target, Action<UseAbilityEventArgs> successCallback = null, Action completeCallback = null)
        {
            // SignalBusGarage.SignalBus.Fire(new ApplyEffectSignalBase(target,
            //     this, successCallback, completeCallback));
        }

        public override void Stop()
        {
            // SignalBusGarage.SignalBus.Fire(new StopEffectSignal(this));
        }

        #endregion
    }
}
