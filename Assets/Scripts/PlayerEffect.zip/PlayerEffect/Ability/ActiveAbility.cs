﻿namespace Amorph
{
    using System;
    using UnityEngine;

    public abstract class ActiveAbility : Ability
    {
        #region Public methods

        public override void Apply(GameObject sender, GameObject target, Action<UseAbilityEventArgs> successCallback = null,
            Action completeCallback = null)
        {
            successCallback += (args) => completeCallback?.Invoke();
        }

        public override void Stop()
        {
        }

        #endregion
    }
}
