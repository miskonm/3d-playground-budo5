﻿using System;
using UnityEngine;

namespace Amorph
{
    public class ApplyEffectSignalBase
    {
        #region Properties
        
        public GameObject TargetObject { get; }
        public PassiveAbility PassiveAbility { get; }
        public Action<UseAbilityEventArgs> SuccessUseCallback { get; }
        public Action CompleteEffectCallback { get; }

        #endregion


        #region Constructor

        public ApplyEffectSignalBase(GameObject targetObject, PassiveAbility passiveAbility, Action<UseAbilityEventArgs> successUseCallback,
            Action onCompleteEffectCallback)
        {
            TargetObject = targetObject;
            PassiveAbility = passiveAbility;
            SuccessUseCallback = successUseCallback;
            CompleteEffectCallback = onCompleteEffectCallback;
        }

        #endregion
    }
}