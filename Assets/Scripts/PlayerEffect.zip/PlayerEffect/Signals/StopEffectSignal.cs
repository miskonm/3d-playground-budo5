﻿namespace Amorph
{
    public class StopEffectSignal
    {
        #region Properties
        
        public PassiveAbility PassiveAbility { get; }

        #endregion


        #region Constructor

        public StopEffectSignal(PassiveAbility passiveAbility)
        {
            PassiveAbility = passiveAbility;
        }

        #endregion
    }
}
