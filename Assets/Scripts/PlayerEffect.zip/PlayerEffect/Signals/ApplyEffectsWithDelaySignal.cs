﻿namespace Amorph
{
    public class ApplyEffectsWithDelaySignal
    {
        #region Properties

        public PassiveAbility PassiveAbility { get; }

        #endregion


        #region Constructor

        public ApplyEffectsWithDelaySignal(PassiveAbility passiveAbility)
        {
            PassiveAbility = passiveAbility;
        }

        #endregion
    }
}
