﻿namespace Amorph
{
    using System;
    using System.Collections.Generic;

    public abstract class BaseEffect
    {
        #region Variables

        private const string Tag = "BaseEffect";

        private float currentDuration;

        protected Action completeCallback;
        protected Action onStartCallback;

        #endregion


        #region Properties

        public Type EffectType { get; }

        public bool IsCompleted { get; private set; }
        public int Level { get; }

        public float DefaultDuration { get; private set; }

        #endregion


        #region Constructor

        protected BaseEffect(Type type, int level, float duration)
        {
            EffectType = type;
            Level = level;

            DefaultDuration = duration;
            currentDuration = DefaultDuration;
        }

        #endregion


        #region Public methods

        public virtual void Tick(float deltaTime)
        {
            if (IsCompleted)
                return;

            if (currentDuration > 0)
                currentDuration -= deltaTime;
            else
                Complete();
        }

        public virtual void ApplyEffectServer(/*List<IPlayerBody> bodies*/)
        {
        }

        // public virtual void ApplyEffectServer(/*IPlayerBody body*/)
        // {
        // }

        public virtual void StopServerEffect(/*List<IPlayerBody> bodies*/)
        {
        }

        public BaseEffect OnStart(Action onStartCallback)
        {
            this.onStartCallback += onStartCallback;

            return this;
        }

        public BaseEffect OnComplete(Action completeCallback)
        {
            this.completeCallback += completeCallback;

            return this;
        }

        public void AddDuration(float duration)
        {
            currentDuration += duration;
        }

        public void SetDuration(float duration)
        {
            currentDuration = duration;
        }

        public virtual void Activate()
        {
            onStartCallback?.Invoke();
        }

        public void CompleteImmediately()
        {
            if (!IsCompleted)
            {
                Complete();
            }
        }

        #endregion


        #region Private methods

        protected virtual void Complete()
        {
            completeCallback?.Invoke();

            IsCompleted = true;
        }

        #endregion
    }
}
