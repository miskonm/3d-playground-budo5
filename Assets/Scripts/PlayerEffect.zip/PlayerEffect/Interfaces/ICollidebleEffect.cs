﻿namespace Amorph
{
    public interface ICollidebleEffect
    {
        // void InCollisionAction(AmorphPlayer owner, IPlayerBody eatablePlayerBody);
        //
        // void OutCollisionAction(IPlayerBody body);
    }
}