﻿namespace Amorph
{
    public interface IPlayerEffectBuilder
    {
        void Start();
        void Terminate();
        void CreateEffect(ApplyEffectSignalBase signal);
    }
}
