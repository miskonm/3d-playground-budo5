﻿namespace Amorph
{
    using System;

    public class BleedEffect : Effect<bool>
    {
        #region Variables

        // private readonly AmorphPlayer player;
        private readonly float damagePerSecondsInPercents;
        private readonly float damagePerSecondsOffset;

        #endregion


        #region Constructors

        public BleedEffect(/*AmorphPlayer player, */float damagePerSecondsInPercents, float damagePerSecondsOffset,
            Action<bool> setter, bool startValue, bool endValue, float duration, Type type, int level) : base(setter,
            startValue, endValue, duration, type, level)
        {
            // this.player = player;
            this.damagePerSecondsInPercents = damagePerSecondsInPercents;
            this.damagePerSecondsOffset = damagePerSecondsOffset;
        }

        #endregion


        #region Public methods

        public override void Activate()
        {
            base.Activate();

            // SignalBusGarage.SignalBus.Fire(new StartBleedingSignal(player, damagePerSecondsInPercents,
            //     damagePerSecondsOffset));
        }

        #endregion


        #region Private methods

        protected override void Complete()
        {
            base.Complete();

            // SignalBusGarage.SignalBus.Fire(new StopBleedingSignal(player));
        }

        #endregion
    }
}
