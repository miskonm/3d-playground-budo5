﻿namespace Amorph
{
    using System;

    public class InfiniteBaseEffect : BaseEffect
    {
        #region Constructors

        protected InfiniteBaseEffect(Type type, int level, float duration) : base(type, level, duration)
        {
        }

        #endregion


        #region Public methods

        public override void Tick(float deltaTime)
        {
        }

        #endregion
    }
}
