﻿namespace Amorph
{
    using System;

    public class InfiniteEffect<T> : InfiniteBaseEffect
    {
        #region Variables

        protected readonly T startValue;
        protected readonly T endValue;
        protected readonly Action<T> setter;

        #endregion


        #region Constructor

        public InfiniteEffect(Action<T> setter, T startValue, T endValue, float duration, Type type, int level) : base(
            type, level, duration)
        {
            this.startValue = startValue;
            this.endValue = endValue;
            this.setter = setter;
        }

        #endregion


        #region Public methods

        public override void Activate()
        {
            base.Activate();

            setter?.Invoke(startValue);
        }

        #endregion


        #region Private methods

        protected override void Complete()
        {
            setter?.Invoke(endValue);

            base.Complete();
        }

        #endregion
    }
}
