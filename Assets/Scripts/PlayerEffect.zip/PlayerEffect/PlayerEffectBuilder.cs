﻿using Photon.Bolt;

namespace Amorph
{
    using System.Collections.Generic;
    using UnityEngine;
    using Zenject;
    using System;
    using System.Collections;

    public class PlayerEffectBuilder : ITickable, IPlayerEffectBuilder
    {
        #region Local data

        private struct PlayerEffectInfo
        {
            public AmorphPlayer Player { get; }
            public BaseEffect Effect { get; }

            public PlayerEffectInfo(AmorphPlayer amorphPlayer, BaseEffect effect)
            {
                Player = amorphPlayer;
                Effect = effect;
            }
        }

        #endregion


        #region Variables

        private const string Tag = nameof(PlayerEffectBuilder);

        private readonly LevelObjectData levelObjectData;
        private readonly PlayersContainer playersContainer;
        private readonly IExitGameSystemServer exitGameSystemServer;
        private readonly CoroutineHandler coroutineHandler;

        private readonly List<PlayerEffectInfo> allEffects = new List<PlayerEffectInfo>();
        private readonly List<PlayerEffectInfo> keyToRemove = new List<PlayerEffectInfo>();

        private bool isStarted = false;

        #endregion


        #region Constructor

        public PlayerEffectBuilder(LevelObjectData levelObjectData, PlayersContainer playersContainer,
            IExitGameSystemServer exitGameSystemServer, CoroutineHandler coroutineHandler)
        {
            this.levelObjectData = levelObjectData;
            this.playersContainer = playersContainer;
            this.exitGameSystemServer = exitGameSystemServer;
            this.coroutineHandler = coroutineHandler;

            SubscribeOnExitGameSystemServerEvents();
        }

        #endregion


        #region Public methods

        public void Tick()
        {
            if (isStarted)
            {
                float deltaTime = Time.deltaTime;

                TickEffects(deltaTime);
            }
        }

        public void Start()
        {
            isStarted = true;
        }

        public void Terminate()
        {
            isStarted = false;

            allEffects.Clear();
        }

        public void CreateEffect(ApplyEffectSignalBase signal)
        {
            AmorphPlayer player = signal.TargetPlayer;

            if (player.IsNull())
            {
                var playerBody = signal.TargetObject.GetComponent<IPlayerBody>();

                if (playerBody.IsNull())
                {
                    return;
                }

                player = playersContainer.GetPlayer(playerBody.PlayerId);
            }

            if (player.PlayerData.IsRespawning)
            {
                GameLogger.Error($"{Tag}, {nameof(CreateEffect)}: Player '{player.UserData.Name}' is respawning! " +
                    $"Ability '{signal.PassiveAbility.Type}'");
            }

            CreateEffectFromData(signal.AbilityLevelCoefficients, signal.PassiveAbility, player,
                signal.SuccessUseCallback, signal.CompleteEffectCallback);
        }

        public void StopEffect(StopEffectSignal stopEffectSignal)
        {
            if (stopEffectSignal.Player == null || stopEffectSignal.PassiveAbility == null)
            {
                return;
            }

            TryStopEffect(stopEffectSignal.Player, stopEffectSignal.PassiveAbility);
        }

        public void CreateEffectWithDelay(ApplyEffectsWithDelaySignal signal)
        {
            coroutineHandler.StartCoroutine(CreateEffectFromDataWithDelay(signal.AbilityLevelCoefficients,
                signal.TargetPlayer, signal.PassiveAbility));
        }

        private IEnumerator CreateEffectFromDataWithDelay(AbilityLevelCoefficients abilityLevelCoefficients,
            AmorphPlayer player, PassiveAbility passiveAbility)
        {
            yield return null;

            CreateEffectFromData(abilityLevelCoefficients, passiveAbility, player, null, null);
        }

        #endregion


        #region Private methods

        private void SubscribeOnExitGameSystemServerEvents()
        {
            exitGameSystemServer.OnPlayerExitGame += ExitGameSystemServer_OnPlayerExitGame;
        }

        private void TickEffects(float deltaTime)
        {
            for (int i = 0, count = allEffects.Count; i < count; i++)
            {
                var playerEffectInfo = allEffects[i];
                var effect = playerEffectInfo.Effect;

                effect.Tick(deltaTime);

                if (effect.IsCompleted)
                {
                    var effectsDataContainer = playerEffectInfo.Player.PlayerEffectsDataContainerServer;

                    List<EffectInfo> effectsList = null;

                    if (effectsDataContainer.ActiveEffects.ContainsKey(effect.EffectType))
                    {
                        effectsList = effectsDataContainer.ActiveEffects[effect.EffectType];
                    }

                    CompleteEffect(playerEffectInfo, allEffects, effectsList);
                }
            }

            RemoveKeys(allEffects);
        }

        private void CompleteEffect(PlayerEffectInfo playerEffectInfo, List<PlayerEffectInfo> playerEffectInfos,
            List<EffectInfo> effectInfos)
        {
            var player = playerEffectInfo.Player;
            var effectsDataContainer = player.PlayerEffectsDataContainerServer;

            if (effectInfos == null || effectInfos.Count == 0)
            {
                keyToRemove.Add(playerEffectInfo);

                return;
            }

            effectsDataContainer.RemoveEffectWithUpdateMask(effectInfos, effectInfos.FirstItem());

            if (effectInfos.Count > 0)
            {
                var currentEffectInfo = effectInfos.FirstItem();

                effectsDataContainer.AddToMask(currentEffectInfo);
                effectsDataContainer.SayEffectAdded(currentEffectInfo, true);

                playerEffectInfos.Add(new PlayerEffectInfo(player, currentEffectInfo.Effect));

                ActivateEffect(player, currentEffectInfo.Effect);
            }

            keyToRemove.Add(playerEffectInfo);
        }

        private void RemoveKeys(List<PlayerEffectInfo> list)
        {
            for (int i = 0; i < keyToRemove.Count; i++)
            {
                var effectInfo = keyToRemove[i];

                DeactivateEffect(effectInfo.Player, effectInfo.Effect);
                list.Remove(effectInfo);
            }

            keyToRemove.Clear();
        }

        private bool CreateEffectFromData(AbilityLevelCoefficients abilityLevelCoefficients,
            PassiveAbility passiveAbility, AmorphPlayer player, Action<UseAbilityEventArgs> successCallback,
            Action onEffectCompleteCallback)
        {
            GameLogger.Log($"{Tag}, {nameof(CreateEffectFromData)}: isStarted '{isStarted}', player " +
                $"'{player.IfNotNull()?.UserData.Name}', passiveAbility '{passiveAbility}'");

            var effect = passiveAbility.GetEffect(abilityLevelCoefficients, player);

            if (effect == null)
            {
                GameLogger.Error($"{Tag}: GetEffect NullReferenceException");

                return false;
            }

            var effectTime = passiveAbility.IsDebuff
                    ? effect.DefaultDuration * player.PlayerEffects.NegativeEffectsTimeFactor
                    : effect.DefaultDuration * player.PlayerEffects.PositiveEffectsTimeFactor;

            effectTime = passiveAbility.IsPassive ? effectTime : effect.DefaultDuration;

            effect.OnComplete(onEffectCompleteCallback);
            effect.SetDuration(effectTime);

            var passiveAbilityLocalId = levelObjectData.GetPassiveAbilityLocalId(passiveAbility);
            var effectInfo = new EffectInfo(effect, passiveAbilityLocalId, effectTime, passiveAbility.IsPassive,
                passiveAbility.IsSpecial, passiveAbility.IsDebuff, passiveAbility.NeedQueue);

            var isEffectCreated = CreateEffectFromInfo(player, effectInfo);

            if (isEffectCreated)
            {
                successCallback?.Invoke(CreateUseAbilityEventArgsFromInfo(effectInfo));
            }

            return isEffectCreated;
        }

        private bool CreateEffectFromInfo(AmorphPlayer player, EffectInfo effectInfo)
        {
            var isEffectCreated = false;

            var effectsDataContainer = player.PlayerEffectsDataContainerServer;

            if (effectsDataContainer == null)
            {
                GameLogger.Error($"{Tag}, {nameof(CreateEffectFromInfo)}: Player {player.UserData.Name} not " +
                    $"initialized with 'PlayerEffectsDataContainerServer'");

                return false;
            }

            var isPassiveEffectLimitReached = effectsDataContainer.IsPassiveEffectLimitReached();

            if (effectInfo.IsSpecial)
            {
                isEffectCreated = AddNewSpecialEffect(player, effectInfo);
            }
            else if (!effectInfo.IsPassive)
            {
                isEffectCreated = TryAddNewEffect(player, effectInfo);
            }
            else if (!effectInfo.NeedQueue)
            {
                isEffectCreated = TryAddNewEffectWithoutQueue(player, effectInfo);
            }
            else
            {
                if (!isPassiveEffectLimitReached || effectInfo.IsDebuff)
                {
                    isEffectCreated = TryAddNewEffect(player, effectInfo);
                }

                if (!isEffectCreated)
                {
                    isEffectCreated = TryAddExistedEffect(player, effectInfo, isPassiveEffectLimitReached);
                }
            }

            return isEffectCreated;
        }

        private bool AddNewSpecialEffect(AmorphPlayer player, EffectInfo effectInfo)
        {
            var effectsDataContainer = player.PlayerEffectsDataContainerServer;
            effectsDataContainer.AddToMask(effectInfo);

            var effect = effectInfo.Effect;
            ActivateEffect(player, effect);

            allEffects.Add(new PlayerEffectInfo(player, effect));

            return true;
        }

        private bool TryAddNewEffect(AmorphPlayer player, EffectInfo effectInfo)
        {
            var effectsDataContainer = player.PlayerEffectsDataContainerServer;
            var effectsDictionary = effectsDataContainer.ActiveEffects;
            var effectType = effectInfo.Effect.EffectType;

            if (!effectsDictionary.ContainsKey(effectType))
            {
                effectsDictionary.Add(effectType, new List<EffectInfo>());
            }

            var effectsList = effectsDictionary[effectType];

            if (effectsList.Count == 0)
            {
                AddEffectWithUpdateMask(player, effectsList, effectInfo, allEffects);

                return true;
            }

            return false;
        }

        private bool TryAddNewEffectWithoutQueue(AmorphPlayer player, EffectInfo effectInfo)
        {
            var effectsDataContainer = player.PlayerEffectsDataContainerServer;
            var effectsDictionary = effectsDataContainer.ActiveEffects;
            var effectType = effectInfo.Effect.EffectType;

            if (!effectsDictionary.ContainsKey(effectType))
            {
                effectsDictionary.Add(effectType, new List<EffectInfo>());
            }

            var effectsList = effectsDictionary[effectType];
            var effect = effectInfo.Effect;

            effectsDataContainer.AddEffectWithUpdateMask(effectsList, effectInfo);
            allEffects.Add(new PlayerEffectInfo(player, effect));

            ActivateEffect(player, effect);

            return true;
        }

        private bool TryAddExistedEffect(AmorphPlayer player, EffectInfo effectInfo, bool isPassiveLimitReached)
        {
            var effectsDataContainer = player.PlayerEffectsDataContainerServer;
            var effectsDictionary = effectsDataContainer.ActiveEffects;
            var effectType = effectInfo.Effect.EffectType;

            if (!effectsDictionary.ContainsKey(effectType))
            {
                return false;
            }

            var effectsList = effectsDictionary[effectType];

            if (effectsList.Count == 0)
            {
                return false;
            }

            return TryAddExistedCommonEffect(player, effectsList, effectInfo, isPassiveLimitReached);
        }

        private bool TryAddExistedCommonEffect(AmorphPlayer player, List<EffectInfo> effectsList,
            EffectInfo newEffectInfo, bool isPassiveLimitReached)
        {
            var effectsDataContainer = player.PlayerEffectsDataContainerServer;
            var currentEffectInfo = effectsList.FirstItem();
            var currentEffect = currentEffectInfo.Effect;
            var newEffect = newEffectInfo.Effect;

            if (newEffectInfo.Effect.Level == currentEffect.Level)
            {
                currentEffect.AddDuration(newEffectInfo.Duration);
                effectsDataContainer.SayEffectAdded(newEffectInfo, true);

                return true;
            }

            if (newEffect.Level < currentEffect.Level)
            {
                if (effectsList.Count > 1)
                {
                    var secondEffectInfo = effectsList[1];

                    secondEffectInfo.Effect.AddDuration(secondEffectInfo.Duration);
                    effectsDataContainer.SayEffectAdded(secondEffectInfo, false);

                    return true;
                }

                if (!newEffectInfo.IsPassive || !isPassiveLimitReached)
                {
                    effectsDataContainer.AddEffect(effectsList, newEffectInfo);

                    return true;
                }
            }
            else
            {
                effectsDataContainer.RemoveEffectWithUpdateMask(effectsList, currentEffectInfo);
                allEffects.Remove(new PlayerEffectInfo(player, currentEffect));

                DeactivateEffect(player, currentEffect, true);

                AddEffectWithUpdateMask(player, effectsList, newEffectInfo, allEffects);

                return true;
            }

            return false;
        }

        private void AddEffectWithUpdateMask(AmorphPlayer player, List<EffectInfo> effectInfos, EffectInfo effectInfo,
            List<PlayerEffectInfo> playerEffectInfos)
        {
            var effectsDataContainer = player.PlayerEffectsDataContainerServer;
            var effect = effectInfo.Effect;

            effectsDataContainer.AddEffectWithUpdateMask(effectInfos, effectInfo);
            playerEffectInfos.Add(new PlayerEffectInfo(player, effect));

            ActivateEffect(player, effect);
        }

        private void ActivateEffect(AmorphPlayer player, BaseEffect effect)
        {
            effect.ApplyEffectServer(player.PlayerBodyContainer.Bodies);
            effect.Activate();
            
            if (effect is ICollidebleEffect activeEffect)
                player.PlayerEffectsDataContainerServer.AddCollidebleEffect(activeEffect);
        }

        private void DeactivateEffect(AmorphPlayer player, BaseEffect effect, bool needComplete = false)
        {
            if (effect is ICollidebleEffect activeEffect)
            {
                player.PlayerEffectsDataContainerServer.RemoveCollidebleEffect(activeEffect);
            }

            effect.StopServerEffect(player.PlayerBodyContainer.Bodies);

            if (needComplete)
            {
                effect.CompleteImmediately();
            }
        }

        private static void TurnOffAllEffectsFromPlayer(AmorphPlayer player)
        {
            var effectDataContainer = player.PlayerEffectsDataContainerServer;

            if (effectDataContainer != null)
            {
                foreach (var effectInfoList in effectDataContainer.ActiveEffects)
                {
                    foreach (var effectInfo in effectInfoList.Value)
                    {
                        effectInfo.Effect.CompleteImmediately();
                    }
                }
            }
        }

        private static void TryStopEffect(AmorphPlayer player, PassiveAbility passiveAbility)
        {
            var effectInfo = player.PlayerEffectsDataContainerServer.GetEffectInfo(passiveAbility);
            effectInfo?.Effect.CompleteImmediately();
        }

        private UseAbilityEventArgs CreateUseAbilityEventArgsFromInfo(EffectInfo effectInfo)
        {
            return new UsePassiveAbilityEventArgs(effectInfo.Duration, effectInfo.IsPassive);
        }

        #endregion


        #region Event handlers

        private static void ExitGameSystemServer_OnPlayerExitGame(BoltConnection connection,
            DisconnectionStatus disconnectionStatus)
        {
            var player = connection.GetPlayer();

            if (!player.IsNull())
            {
                TurnOffAllEffectsFromPlayer(player);
            }
        }

        #endregion
    }
}
